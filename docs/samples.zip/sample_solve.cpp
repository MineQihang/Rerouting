#include "rerouting.h"
#include <bits/stdc++.h>

using namespace std;

static const int MAX_EDGE_QUANTITY = 40;
static const int MAX_FREQ_QUANTITY = 32;

int N, M, W, K;
vector<Edge> edges;
vector<Service> services;
vector<Route> currentRoutes; // Current answer state
// Frequencies for current paths that were reserved, i's bit of number 1, if this frequency is reserved, 0 otherwise
vector<long long> curReservedFrequenciesMask;
// Frequencies for current initials paths that were reserved, i's bit of number 1, if this frequency is reserved, 0 otherwise
vector<long long> initReservedFrequenciesMask;
set<int> deletedEdges;
int belongingService[MAX_EDGE_QUANTITY + 1][MAX_FREQ_QUANTITY + 1];

/**
 * Called once before edge removal requests for initialization
 *
 * @param n quantity of nodes
 * @param m quantity of edges
 * @param w quantity of frequency
 * @param k quantity of services
 * @param initEdges edges
 * @param initServices services
 */
void init(int n, int m, int w, int k, vector<Edge> initEdges, vector<Service> initServices) {
    N = n; M = m; W = w; K = k; edges = initEdges; services = initServices;
    deletedEdges.clear();
    curReservedFrequenciesMask = vector<long long>(initEdges.size() + 1, 0ll);
    initReservedFrequenciesMask = vector<long long>(initEdges.size() + 1, 0ll);
    currentRoutes.resize(k);
    memset(belongingService, 0, sizeof belongingService);
    for (const auto &[id, s, t, freq, p]: initServices) {
        currentRoutes[id - 1].service_id = id;
        currentRoutes[id - 1].w = freq;
        currentRoutes[id - 1].p = p;
        for (int edgeId: currentRoutes[id - 1].p) {
            initReservedFrequenciesMask[edgeId] |= (1ll << freq); // Reserved the frequency for the edge
            curReservedFrequenciesMask[edgeId] |= (1ll << freq); // Reserved the frequency for the edge
            belongingService[edgeId][freq] = id;  // Indicate freq at edge belongs to the service
        }
    }
}

/**
 * Edge deletion request. After the request, it will no longer be possible to use this edge and all edges deleted before.
 * if id turns out to be equal to 0, then you need to return to the original state and ignore all previous deletion requests.
 *
 * @param deletedEdgeId Id of deleted Edge. If id equal 0 need to reset all edges removed before this.
 * @return All laid service paths taking into account remote edges
 */
vector<Route> request(int deletedEdgeId) {
    if (deletedEdgeId == 0) // Reset to the original state
        init(N, M, W, K, edges, services);
    else {
        deletedEdges.insert(deletedEdgeId); // Remember all the deleted edges so as not to use them
        for (Route &route: currentRoutes)
            for (int i = 0; i < route.p.size(); i++) // Clear all failed path by deleted edge deletedEdgeId
                if (deletedEdgeId == route.p[i]) {
                    for (int edgeId: route.p)
                        curReservedFrequenciesMask[edgeId] ^= (1ll << route.w); // Release the frequency for the edge
                    route.w = 0;
                    route.p.clear();
                    break;
                }
        for (Route &route: currentRoutes) {
            if (!route.p.empty()) continue; // If the path has already been laid, then it cannot be re-laid
            for (int freq = 1; freq <= W; freq++) {
                if (!route.p.empty()) continue;
                int start = services[route.service_id - 1].s, lastInPathV = start, end = services[route.service_id - 1].t;
                vector<int> edgesPath;
                set<int> nodesInPath;
                nodesInPath.insert(start);
                for (Edge edge: edges) {
                    if (deletedEdges.count(edge.id) == 1) continue; // Checking if an edge has been removed
                    if (curReservedFrequenciesMask[edge.id] >> freq & 1ll) continue; // Checking whether the frequency at edge is reserved
                    // Checking whether edge was reserved in the initial paths, and if it was reserved, whether it belongs to the current route
                    if ((initReservedFrequenciesMask[edge.id] >> freq & 1ll) && belongingService[edge.id][freq] != route.service_id) continue;
                    if (edge.v == lastInPathV || edge.u == lastInPathV) { // Try to add edge to current path
                        int other = (edge.v ^ edge.u) ^ lastInPathV;
                        if (nodesInPath.count(other)) continue; // Check to guarantee simple path (without self-intersections)
                        lastInPathV = other;
                        nodesInPath.insert(other);
                        edgesPath.push_back(edge.id);
                    }
                    if (lastInPathV == end) { // Check to path is found
                        route.p = edgesPath;
                        route.w = freq;
                        for (int edgeId: route.p) {
                            curReservedFrequenciesMask[edgeId] |= (1ll << freq); // Reserve frequency on edge
                        }
                        break;
                    }
                }
            }
        }
    }
    return currentRoutes;
}